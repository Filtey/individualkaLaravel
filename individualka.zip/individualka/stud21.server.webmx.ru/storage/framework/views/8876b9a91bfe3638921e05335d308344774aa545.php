

<?php $__env->startSection('content'); ?>
	
	<h1><?php echo e($data->title); ?></h1>
	<img src="images/<?php echo e($data->img); ?>">
	<p>
	<?php echo $data->content; ?>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /sites/stud21.server.webmx.ru/resources/views/main.blade.php ENDPATH**/ ?>