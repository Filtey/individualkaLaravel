

<?php $__env->startSection('content'); ?>
	
	<h1>Консоль управления</h1>
	<form action="/form" method="post">
		<?php echo csrf_field(); ?>
		<input type="submit" value="Прикрепить новую страницу">	
	</form>
	<h2>Редактирование данных</h2>
	
	<!-- выводим записи верхнего уровня, добавляем ссылку на изменение -->
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<h4>
			<?php echo e($item->title); ?> (<a href="/console/update/<?php echo e($item->id); ?>">Изменить</a>) 
		</h4>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /sites/stud21.server.webmx.ru/resources/views/console/index.blade.php ENDPATH**/ ?>