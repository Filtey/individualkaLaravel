<?php $__env->startSection('content'); ?>
	
	<h1><?php echo e($data->title); ?></h1>
	<?php if($data->img !=null): ?>
	<img src="images/asset/<?php echo $data->img; ?>">
	<?php endif; ?>

	<?php echo $data->content; ?>


	<?php $__currentLoopData = $attachdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<h2><?php echo e($item->title); ?> </h2>
	
	<?php if($item->img !=null): ?>
		<img src="images/asset/<?php echo e($item->img); ?>">
	<?php endif; ?>
		<p>
			<?php echo $item->content; ?>			
		</p>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /sites/stud21.server.webmx.ru/resources/views/custom.blade.php ENDPATH**/ ?>