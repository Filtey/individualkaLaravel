

<?php $__env->startSection('content'); ?>

	<h1>Форма</h1>

	<!-- 
	подключаем форму, используем одну форму на обновление/добавление данных
	в форме в текстовые поля подставим данные обновляемой записи (если они существуют)
	-->
	<?php echo $__env->make('console.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- 
	если редактируемая запись может содержать (свойство allowed) и содержит подчиненные записи
	выведем их с добавлением ссылки на изменение
	-->
	<?php if(isset($attachdata) && count($attachdata)): ?>
		<hr>					
		<h2>Прикрепленные записи</h2>						
		<?php $__currentLoopData = $attachdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php echo e($item->title); ?> (
				<a href="/console/update/<?php echo e($item->id); ?>">Изменить</a> /  
				<a href="/admin/delete/<?php echo e($item->id); ?>">Удалить</a>) </p>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<?php endif; ?> 

	<!--  
	если родительская запись разрешает прикреплять подчиненные (свойство allowed записи) 
	то выводим форму добавления новой записи, при этом
	не забыть передать идентификатор родительской записи (свойство parent)
	-->
	<?php if(isset($data) && $data->allowed): ?>
		<form class="console" action="/console/add" method="post">
			<input type="hidden" name="parent" value="<?php echo e($data->id); ?>"><p>	
			<input type="submit" value="Прикрепить новую запись">
			<?php echo csrf_field(); ?>
		</form>
	<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /sites/stud21.server.webmx.ru/resources/views/console/modification.blade.php ENDPATH**/ ?>