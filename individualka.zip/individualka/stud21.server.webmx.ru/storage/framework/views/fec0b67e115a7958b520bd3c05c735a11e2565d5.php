<!doctype html> 
<html lang="ru">
	<head> 
		<meta charset="UTF-8">
		<title>Музеи мира</title> 
		<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet" type="text/css"><!--подключаем файл стилей-->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	</head>
	
	<body>
		


<!-- < ?php 
			print_r($data); выводит всю таблицу из бд
		?> -->
			 <!--блок навигации, одинаковый для все страниц сайта-->
 <!--<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
< ?php print_r($item->name); print_r($item->title); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->

 <nav>

  <ul class="menu">
  <?php $__currentLoopData = $menu_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
  <?php if($item->parent==0): ?>
  <li><a style="color:black;" href="/<?php echo e($item->name); ?>"><?php echo e($item->title); ?></a>
  	<ul class="submenu">
  
  	<?php 
  	$attachdata = DB::table("posts")->where("parent", "=", $item->id)->get();  
  	?>
  	<?php if($attachdata !=null): ?>
     <?php $__currentLoopData = $attachdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><a a style="color:black;" href="/<?php echo e($parentss->name); ?>"><?php echo e($parentss->title); ?></a></li>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  	<?php endif; ?>
  	</ul>
  <?php endif; ?>

</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
	<li><a a style="color:black;" href="/console">КОНСОЛЬ</a></li>

  </ul>
</nav>  


			<!--  <nav>
				<ul class="menu">
					<li><a href="/muzeisite/public">ГЛАВНАЯ</a></li>
					<li><a href="/muzeisite/public/velikie-muzei">ВЕЛИКИЕ МУЗЕИ</a>
					<li><a href="/muzeisite/public/novosti">НОВОСТИ</a>	
					<li><a href="/muzeisite/public/zhivopis">ЖИВОПИСЬ</a>
						<ul class="submenu">
							<li><a href="/muzeisite/public/zhivopis/russkaya-zhivopis">РУССКАЯ ЖИВОПИСЬ</a></li>
							<li><a href="/muzeisite/public/zhivopis/ispanskaya-zhivopis">ИСПАНСКАЯ ЖИВОПИСЬ</a></li>
							<li><a href="/muzeisite/public/zhivopis/italyanskaya-zhivopis">ИТАЛЬЯНСКАЯ ЖИВОПИСЬ</a></li>
							<li><a href="/muzeisite/public/zhivopis/gollandskaya-zhivopis">ГОЛЛАНДСКАЯ ЖИВОПИСЬ</a></li>
						</ul>
					</li>  
					<li><a href="/muzeisite/public/skulptura">СКУЛЬПТУРА</a></li>
					<li><a href="/muzeisite/public/goroda">ГОРОДА</a>
						<ul class="submenu">
							<li><a href="/muzeisite/public/goroda/barselona">БАРСЕЛОНА</a></li>
							<li><a href="/muzeisite/public/goroda/london">ЛОНДОН</a></li>
							<li><a href="/muzeisite/public/goroda/moskva">МОСКВА</a></li>
							<li><a href="/muzeisite/public/goroda/parizh">ПАРИЖ</a></li>
						</ul>
					</li>
					<li><a href="/muzeisite/public/neobychnye-muzei-mira">НЕОБЫЧНЫЕ МУЗЕИ</a></li>
					<li><a href="/muzeisite/public/console">КОНСОЛЬ</a></li>
				</ul>
			</nav> -->						 
			<!--блок содержит раздел навигации и контент страницы-->		
			<div class="wrapper">			
			<div class="content"> 
				<div class="row">

					<?php echo $__env->yieldContent('content'); ?>

				</div>
			</div>			
		</div>
		
		<footer><!--подвал сайта-->
		<div>
			<p><i>Музеи мира и картины известных художников.<br/>
			Заметили ошибку на странице?<br/>
			Выделите её мышкой и нажмите Ctrl+Enter	</i></p>
		</div>
		</footer>
	</body>
</html><?php /**PATH /sites/stud21.server.webmx.ru/resources/views/layouts/app.blade.php ENDPATH**/ ?>